<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div id="main">
<div id="login">
<h2>Student's Form</h2>
<hr/>
<form action="insert.php" method="post">
<label> Name :</label>
<input type="text" name="name" id="name" required="required" placeholder="Please Enter Name"/><br /><br />
<label> Email :</label>
<input type="email" name="email" id="email" required="required" placeholder="john123@gmail.com"/><br/><br />
<label> User name :</label>
<input type="text" name="user_name" id="user_name" required="required" placeholder="Please Enter Your user name"/><br/><br />
<label> contact :</label>
<input type="tel" id="phone" name="phone" pattern="[0-9]{10}"><br /><br />
<label for="pwd">Password:</label>
<input type="password" id="pwd" name="pwd"><br /><br />
<input type="submit" value=" Submit " name="submit"/><br />
</form>
<hr>
<hr>

<form action="insert.php/login" method="post">
<label> User name :</label>
<input type="text" name="user_name" id="user_name" required="required" placeholder="Please Enter Your user name"/><br/><br />
<label for="pwd">Password:</label>
<input type="password" id="pwd" name="pwd"><br /><br />
<input type="submit" value=" Submit " name="submit"/><br />
</form>


</div>

</div>
<?php 

echo "hello";

echo "Get IP address: User IP Address - ". $_SERVER['REMOTE_ADDR'];

?>

</body>
</html>
