<?php require('UserInfo.php'); ?>

<?php
$servername = "localhost";
$username = "root";
$password = "Tanu@1234";

try {
    $conn = new PDO("mysql:host=$servername;dbname=ammex", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?>


<?php
$_REQUEST['pwd']
Password ENcrypt
// Attempt insert query execution
$sql = "INSERT INTO user (uname, email, username, contact, pswd) VALUES 
                        (:uname, :email, :username, :phone, :pwd)";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':uname', $_REQUEST['name']);
                            $stmt->bindParam(':username', $_REQUEST['user_name']);
                            $stmt->bindParam(':email', $_REQUEST['email']);
                            $stmt->bindParam(':phone', $_REQUEST['phone']);
                            $stmt->bindParam(':pwd', $_REQUEST['pwd']);

                            // Execute the prepared statement
                            $stmt->execute();
                        

?>

<?php
// 2 Factor Authentication Not Impelemted Email Verification, Mobile OTP, Google Authenticator
function login (){
    $ip = UserInfo::get_ip();
    $device = UserInfo::get_device();
    $os = UserInfo::get_os();
    $browser = UserInfo::get_browser();



}

function logout(){

}
function set_cookies(){
    //after login
}

function unset_cookies(){
    //after logout
}

function set_session(){
    //after login
}

function unsetset_cookies(){
    //after logout
}


?>
// 10 Things which can be used for user validation
1. IP tracking during login
2. PASSWORD - Encryption
3. Cookie
4. Session - WHen user is loggrd in
5. JWT 
6. User movement logs
7. OS
8. Browser
9. Encryption of Database
10. Device
11. 