import App from "./App";

/**
 * Initializing demo
 */
new App();
